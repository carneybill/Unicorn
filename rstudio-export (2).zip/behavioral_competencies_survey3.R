# Employer Survey - Behavioral Competencies
library(shiny)
library(RMySQL)

## Database Information
host <- ""
dbname <- "unicorn"
user <- "bcarney"
password <- "uniconl0g1n"

## Table Information
table_name <- "employer_survey3"
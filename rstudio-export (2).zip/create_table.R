# Database Information
host <- "marketing-apps.csa7qlmguqrf.us-east-1.rds.amazonaws.com"
dbname <- "RStudioSurvey"
user <- "RStudioSurvey"
password <- "RStudioL0g1n"

# Connects all together
mydb <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)

# for making tables only will delete everything and write over
# dbSendQuery(mydb, "drop table if exists eval_feedback")

# Create Table
dbSendQuery(mydb, "
            CREATE TABLE eval_feedback (
            row_names TEXT,
            submit TEXT,
            eval_product TEXT,
            eval_freq_r TEXT,
            eval_used_r TEXT,
            eval_r_users TEXT,
            eval_install TEXT,
            eval_docs TEXT,
            eval_complete TEXT,
            eval_no_joy TEXT,
            eval_experience INT,
            eval_prod_experience INT,
            eval_exp_prod_comment TEXT,
            eval_purchase INT,
            eval_rstudio_connect TEXT,
            eval_rstudio_isp TEXT,
            eval_rstudio_ssp TEXT,
            eval_rstudio_os_desk TEXT,
            eval_rstudio_os_server TEXT,
            eval_rstudio_os_shiny TEXT,
            eval_rstudio_shinyapp TEXT,
            eval_products_alt_used TEXT,
            eval_nps INT,
            eval_sales_talk TEXT,
            eval_support_talk TEXT,
            eval_other_feedback TEXT)")
---
  output:
  flexdashboard::flex_dashboard:
  css: dashboard.css
logo: logo.png
orientation: rows
runtime: shiny
---
  
  ```{r setup, include=FALSE}
library(flexdashboard)
library(tidyverse)
library(RCurl)
library(stringr)
library(RMySQL)
library(bsplus)
library(DT)
library(forcats)
library(wordcloud)
library("leaflet") 

sess <- read_csv("sessions_summary.csv")

sess_detail <- read_csv("sessions_detailed.csv")

attendees1 <- read.csv("eventbrite_report.csv")

# load survey data 
host <- "marketing-apps.csa7qlmguqrf.us-east-1.rds.amazonaws.com"
dbname <- "RStudioSurvey"
user <- "RStudioSurvey"
password <- "RStudioL0g1n"
con <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)
survey <- dbReadTable(con, "conf_feedback")
dbDisconnect(con)


survey_unique  <- survey %>%
  filter(submit == 1) %>% 
  as_tibble() %>% 
  mutate(conf_overall = parse_double(conf_overall),
         conf_nps = parse_double(conf_nps),
         conf_repeat = parse_double(conf_repeat),
         conf_content = parse_double(conf_content),
         conf_purchase = parse_double(conf_purchase),
         conf_speakers = parse_double(conf_speakers),
         conf_other_feedback = parse_double(conf_other_feedback))

# load tutorial data 
host <- "marketing-apps.csa7qlmguqrf.us-east-1.rds.amazonaws.com"
dbname <- "RStudioSurvey"
user <- "RStudioSurvey"
password <- "RStudioL0g1n"
con <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)
train <- dbReadTable(con, "train_conf_feedback")
dbDisconnect(con)

train_unique <- train %>% 
  filter(submit == 1) %>% 
  as_tibble() %>% 
  mutate(train_conf_overall = parse_double(train_conf_overall),
         train_conf_nps = parse_double(train_conf_nps),
         train_conf_repeat = parse_double(train_conf_repeat),
         train_conf_helpful = parse_double(train_conf_helpful),
         train_conf_purchase = parse_double(train_conf_purchase),
         train_conf_speakers = parse_double(train_conf_speakers),
         train_conf_other_feedback = parse_double(train_conf_other_feedback))

posts <- read_csv("activity_stream.csv")

prof <- read_csv("profiles.csv")

feedback <- read_csv("feedback.csv")


### helper functions

# param nps_data - a vector of nps scores
npsPlot <- function(nps_data){
  n <- nps_data %>% na.omit() %>% length() 
  nps <- round((sum(nps_data > 8)/n - sum(nps_data < 7)/n)*100)
  
  nps_categories <- tibble(
    detractor = sum(nps_data < 7),
    neutral = sum(nps_data %in% c(7,8)),
    promoter = sum(nps_data > 8)
  ) 
  
  if(sum(nps_categories/n) != 1){ stop("NPS Calculation doesn't add to 100%")}
  
  nps_data_t <- tibble(nps_data = nps_data)
  
  # set appropriate colors
  nps_plot <- nps_data_t %>% 
    mutate(color = ifelse(nps_data < 7, "b", ifelse(nps_data > 8, "c", "a")))
  
  label_y <- (max(nps_categories/n) + 0.05)*max(nps_categories) 
  nps_perc_label <- paste0(round(nps_categories/n*100,0), "% ", str_to_title(colnames(nps_categories)))
  nps_labels = data.frame(x = c(5.5, 7.5, 9.5), y = rep(label_y, 3), label = nps_perc_label)
  
  
  ggplot(nps_plot, aes(x=nps_data)) +
    geom_bar(aes(fill = color)) +
    theme_minimal() + 
    theme(
      title = element_text(color = "#404040"),
      text = element_text( size = 14)
    ) + 
    labs(
      x = "How likely are you to recommend rstudio::conf to a friend?",
      y = paste0(n, " Survey Responses / 464 Attendees"),
      title = paste0("Net Promoter Score of ", nps)
    ) + 
    scale_fill_manual(values = c("#4287c7", "#f9b02d", "#789d57"), guide = FALSE) + 
    geom_text(data = nps_labels, aes(x=x, y=y, label = label))
  
}  



```

```{r eval = FALSE}

# This code chunk is not evaluated, but it includes the steps necessary 
# to recreate feedback.csv, which contains anonymized feedback 
# and a sentiment score (from IBM's Alchemy API)

sess <- read_csv("sessions_detailed.csv") %>% 
  select(Text = Feedback) %>% 
  na.omit() %>% 
  unique() %>% 
  mutate(source = "sessions")

comm <- read_csv("comments.csv") %>% 
  select(Text) %>%
  na.omit() %>% 
  unique() %>% 
  mutate(source = "comments")


post <- read_csv("activity_stream.csv") %>% 
  select(Text) %>% 
  na.omit() %>% 
  unique() %>% 
  mutate(source = "post")

survey_clean <- survey %>% 
  select(conf_like, conf_dislike, conf_other_feedback, conf_purchase) %>% 
  na.omit %>% 
  gather(key = "source", value = "Text") %>% 
  unique() %>% 
  as_tibble()

train_clean <- train %>% 
  select(train_conf_like, train_conf_dislike, train_conf_other_feedback) %>% 
  gather(key = "source", value = "Text") %>% 
  na.omit %>% 
  unique() %>% 
  as_tibble()

feedback <- rbind(sess, comm, post, survey_clean, train_clean) %>% 
  filter(Text != "")


getSentiment <- function(text) {
  url <- "https://gateway-a.watsonplatform.net/calls/text/TextGetTextSentiment"
  apikey <- "0562ea7814492bc86cd7ca57ce8cefba422a7db8"  
  full_url <- paste0(url, "?text=",curlEscape(text), "&outputMode=json&apikey=", apikey)
  response <- httr::GET(full_url)
  content <- httr::content(response)
  sentiment <- as.numeric(content$docSentiment$score)
  sentiment <- ifelse(identical(sentiment, numeric(0)) || is.na(sentiment), NA, sentiment)
  sentiment
}

feedback$sentiment = vector(length = nrow(feedback))
for(i in 1:nrow(feedback)){
  feedback$sentiment[i] = getSentiment(feedback$Text[i])
}

write_csv(feedback, "feedback.csv")
```


rstudio::conf
========================
  
  Row {data-height=50}
------------------------
  
  
  ###  {.no-title}
  
  ```{r}
npsPlot(survey_unique$conf_nps)
```

### {.no-title}

```{r}
n <- nrow(survey_unique)

color  <- ifelse(survey_unique$conf_overall < 7, "b", ifelse( survey_unique$conf_overall> 8, "c", "a"))

ggplot(survey_unique, aes(x=conf_overall)) +
  geom_bar(aes(fill = color)) +
  theme_minimal() + 
  theme(
    title = element_text(color = "#404040")
  ) + 
  labs(
    x = "rstudio::conf Overall Rating",
    y = paste0(n, " Survey Responses / 464 Attendees"),
    title = paste0("Average Rating ", round(mean(survey_unique$conf_overall, na.rm = TRUE),1))
  ) + 
  scale_fill_manual(values = c("#4287c7", "#f9b02d", "#789d57"), guide = FALSE)


```


Row {data-height=20}
----------------------
  
  
  ### {.no-title}
  
  ```{r}
valueBox(464, "Attendees", color = "white", icon = "fa-users")
```


### {.no-title}

```{r}
#sessions
sess %>% 
  filter(Track %in% c("rmd", "scaling", "deeper", "htmlwidgets", "shiny", "tidyverse")) %>% 
  count() %>% 
  valueBox("Sessions", color = "white", icon = "fa-volume-up")
```

### {.no-title}

```{r}
sum(posts$Likes) %>% 
  valueBox("Likes", color = "white", icon = "fa-thumbs-up")
```


Row {data-height=20}
----------------------
  
  ### {.no-title}
  
  ```{r}
sum(posts$Comments) %>% 
  valueBox("Comments", color = "white", icon = "fa-comments")
```


### {.no-title}

```{r}
sess %>% 
  select(Speaker) %>% 
  unique() %>% 
  count() %>% 
  valueBox("Speakers", color = "white", icon = "fa-microphone")
```

### {.no-title}

```{r}
valueBox(411, "Wizards", color = "white", icon = "fa-magic")
```



Sessions 
========================
  
  Row {data-height = 30}
-------------------------
  
  ### {.no-title}
  
  ```{r}
sentiment <- feedback %>% 
  filter(source == "sessions") %>% 
  summarise(avg_sentiment = mean(sentiment, na.rm = TRUE))
gauge(round(sentiment$avg_sentiment,2), min = -1, max = 1,label = "Sentiment", sectors = gaugeSectors(success = c(0,1), danger = c(-1,0)))
```

### {.no-title}

```{r}
valueBox(round(mean(survey_unique$conf_speakers, na.rm = TRUE),1), "Avg Speaker Rating", color = "white", icon = "fa-check")
```


Row {data-height=60}{.tabset}
----------------------------
  
  ### Tracks
  
  ```{r}
all <- sess_detail %>% 
  select(Target_Id, Rate) %>% 
  left_join(sess, by = c("Target_Id" = "Id")) %>% 
  select(-Rate.y, Rate = Rate.x, -Ratings, -Bookmarks, -Views)

track <- all %>% 
  group_by(Track) %>% 
  summarise(avg_rating = mean(Rate),
            med_rating = median(Rate),
            num_reviews = n()) %>% 
  filter(Track != "other", Track != "reception")

ggplot(track, aes(x = reorder(Track, avg_rating), y = avg_rating)) +
  geom_bar(stat = "identity", fill = "#4287c7") + 
  geom_text(aes(x = Track, y = avg_rating-0.15, label = num_reviews), color = "white") +
  theme_minimal() + 
  theme(
    title = element_text(color =  "#404040")
  ) +
  coord_flip() + 
  labs(
    title = "Ratings by Track",
    x = "",
    y = "5 Stars",
    caption = "Label = # of Reviews"
  ) +
  scale_x_discrete(labels = c(
    "htmlwidget" = "htmlwidets" ,
    "harrypotter" = "Harry Potter", 
    "tidyverse" = "Tidyverse",
    "keynote" = "Keynotes",
    "rsc" = "RStudio Connect Lounge",
    "deeper" = "Going Deeper", 
    "lightening" = "Lightening Talks",
    "shiny" = "Shiny",
    "scaling" = "Scaling R",
    "rmd" = "R Markdown",
    "tutorial" = "Tutorials"
  ))


```


### Talks

```{r}
all <- sess_detail %>% 
  select(Target_Id, Rate) %>% 
  left_join(sess, by = c("Target_Id" = "Id")) %>% 
  select(-Rate.y, Rate = Rate.x, -Ratings, -Bookmarks, -Views)

talk <- all[!(str_detect(all$Title,fixed("Registration")) | 
                str_detect(all$Title,"Break") | 
                str_detect(all$Title,"Refreshments")
),] %>% 
  group_by(Title) %>%
  summarise(avg_rating = mean(Rate),
            med_rating = median(Rate),
            num_reviews = n()) 

harryRating <- talk %>% 
  filter(Title == "Harry Potter World") %>% 
  select(avg_rating) %>% 
  as.numeric()

talks <- talk %>% 
  filter(avg_rating >= harryRating) 

ggplot(talks, aes(x = reorder(Title, avg_rating), y = avg_rating)) +
  geom_bar(stat = "identity", fill = "#4287c7") + 
  geom_text(aes(x = Title, y = avg_rating-0.15, label = num_reviews), color = "white") +
  theme_minimal() + 
  theme(
    title = element_text(color =  "#404040")
  ) +
  coord_flip() + 
  labs(
    title = "Talks More Popular Than Harry Potter",
    x = "",
    y = "5 Stars",
    caption = "Label = # of Reviews"
  ) 

```


### Feedback 
```{r}
feedback %>% 
  filter(source == "sessions", !is.na(sentiment)) %>% 
  mutate(sentiment = round(sentiment, 2)) %>% 
  select(Text, sentiment) %>% 
  datatable(extensions = 'Scroller', colnames = c("Feedback", "Sentiment"), options = list(pageLength = 300, scrollY = 200, lengthChange = FALSE, deferRender = TRUE, order = list(list(2,'desc')))) %>% 
  formatStyle(
    'sentiment',
    color = styleInterval(c(0), c('#f9b02d', '#789d57'))
  ) 
```

Attendees 
====================
  
  Row
----------------------
  
  ### Corporate Attendees (Sized by Number of Attendees per Company)
  
  ```{r}
# getCompany <- function(email){str_match(email, ".*@(.*)\\.")[,2]}
# 
# corporate_attendees <- atten %>% 
#   select(Email1, Email2) %>% 
#   gather(key="source", value="address") %>% 
#   select(-source) %>% 
#   mutate(domain = getCompany(address)) %>% 
#   filter(domain !="gmail",
#          domain !="yahoo",
#          domain != "hotmail") %>% 
#   select(domain) %>% 
#   group_by(domain) %>% 
#   summarise(count = n())


d <- read_csv("corporate_attendees.csv")
wordcloud(words = d$Company, freq = d$Attendees, min.freq = 1,
          max.words=200, random.order=FALSE, rot.per=0, fixed.asp = FALSE, 
          colors=brewer.pal(8, "Dark2"))  


```


### {.no-title}
```{r}
n <- nrow(survey_unique)

color  <- ifelse(survey_unique$conf_purchase < 7, "b", ifelse( survey_unique$conf_purchase> 8, "c", "a"))

ggplot(survey_unique, aes(x=conf_purchase)) +
  geom_bar(aes(fill = color)) +
  theme_minimal() + 
  theme(
    title = element_text(color = "#404040")
  ) + 
  labs(
    x = "How likely are you to purchase RStudio commercial products?",
    y = paste0(n, " Survey Responses / 464 Attendees"),
    title = paste0("Will you purchase? ", round(mean(survey_unique$conf_purchase, na.rm = TRUE),1), "/10")
  ) + 
  scale_fill_manual(values = c("#4287c7", "#f9b02d", "#789d57"), guide = FALSE)

```

Future
====================
  
  Row {data-height=40}
----------------------
  
  ### {.no-title}
  ```{r}
ds <- read_csv("data_size_poll.csv")
ds$Size <- factor(x = 1:5, labels = ds$Size, levels = 1:5)
ggplot(ds, aes(x = Size, y = votes)) + 
  geom_bar(stat = "identity", fill = "#d54a30" ) + 
  theme_minimal() +
  coord_flip() + 
  labs(
    title = "How Big is Your Data?", 
    x ="",
    y = ""
  )
```

### {.no-title}

```{r}
survey_unique %>% 
  select(conf_comp_r_users) %>% 
  group_by(conf_comp_r_users) %>% 
  summarise(count = n()) %>% 
  mutate(category = factor(conf_comp_r_users, 
                           levels =c("<5", ">5<25", ">25<100", ">100", "I have no idea"),
                           labels =c("<5", ">5<25", ">25<100", ">100", "I have no idea"))) %>% 
  select(-conf_comp_r_users) %>% 
  ggplot(aes(x = category, y = count)) +
  geom_bar(stat = "identity", fill = "#789d57") + 
  theme_minimal() +
  coord_flip() + 
  labs(
    y = "",
    x = "",
    title = "How many people use R in your organization?"
  )
```


Row {data-height=40}
----------------------
  
  ### {.no-title}
  
  ```{r}
ds <- read_csv("next_loc_poll.csv")
ds$Location <- factor(x = 1:4, labels = ds$Location, levels = 1:4)
ggplot(ds, aes(x = reorder(Location, Votes), y = Votes)) + 
  geom_bar(stat = "identity", fill = "#f9b02d" ) + 
  theme_minimal() +
  coord_flip() + 
  labs(
    title = "2018 rstudio::conf Location?", 
    x ="",
    y = ""
  )
```

### {.no-title}

```{r}
ds <- read_csv("week_days_poll.csv")
ds$week_days <- factor(x = 1:5, labels = ds$week_days, levels = 1:5)
ggplot(ds, aes(x = reorder(week_days, Votes), y = Votes)) + 
  geom_bar(stat = "identity", fill = "#4287c7" ) + 
  theme_minimal() +
  coord_flip() + 
  labs(
    title = "2018 rstudio::conf Days?", 
    x ="",
    y = ""
  )
```


Feedback
====================
  
  Row {data-height=50}
------------------------
  
  ### Likes
  
  ```{r}
feedback %>% 
  filter(source == "conf_like") %>% 
  select(Feedback = Text, Sentiment = sentiment) %>% 
  datatable(extensions = 'Scroller', options = list(pageLength = 300, deferRender = TRUE,  scrollY = 200, lengthChange = FALSE, order = list(list(2,'desc'))))
```



### Dislikes

```{r}
feedback %>% 
  filter(source == "conf_dislike", !is.na(sentiment)) %>% 
  select(Feedback = Text, Sentiment = sentiment) %>% 
  datatable(extensions = 'Scroller', options = list(pageLength = 300, deferRender = TRUE,  scrollY = 200, lengthChange = FALSE, order = list(2,'asc')))
```

Training Days
========================
  
  ```{r}
selectizeInput("session", "Choose Training Session", choices = c("All", "Advanced R", "Intermediate Shiny", "Tidyverse"))

train_unique_selected <- reactive({
  if(input$session == "All") {
    train_unique
  } else { 
    train_unique %>% 
      filter(train_conf_session == input$session)
  }
})

getSummary <- function(data, metric,label){
  
  data_sub <- data %>% 
    select_(paste0(metric)) 
  colnames(data_sub) <- c("metric")
  data_sub %>% 
    group_by(metric) %>% 
    summarise(count = n()) %>% 
    mutate(response = str_to_title(metric),
           section = label) %>%
    arrange(response) %>%
    select(-metric)
}
```


Row {data-height=60}{.tabset .tabset-fade}
----------------------------
  ### Training Feedback
  ```{r}
renderPlot({
  
  fields <- c("train_conf_helpful", "train_conf_repeat")
  facet_title <- c("Was content helpful?", "Would you attend again?")
  content <- map2_df(fields, facet_title, ~getSummary(train_unique_selected(), .x, .y))
  
  ggplot(content, aes(x = reorder(response, as.numeric(response)), y = count)) +
    geom_bar(stat = "identity", aes(fill = section)) +
    facet_wrap(~section, scales = "free", nrow = 1, ncol = 4) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 60, hjust = 1), 
      text = element_text( size = 14),
      panel.spacing = unit(1, "cm")
    ) +
    labs(
      x="",
      y="",
      title=""
    ) +
    scale_fill_manual(values = c("#789d57", "#75aadb"), guide = FALSE) 
})
#train_conf_other_feedback
#train_conf_repeat
#train_conf_helpful
#train_conf_length
#train_conf_content
```

### Content Feedback
```{r}
renderPlot({
  
  fields <- c("train_conf_length", "train_conf_content")
  facet_title <- c("Course Length", "Course Overall")
  content <- map2_df(fields, facet_title, ~getSummary(train_unique_selected(), .x, .y))
  
  ggplot(content, aes(x = reorder(response, as.numeric(response)), y = count)) +
    geom_bar(stat = "identity", aes(fill = section)) +
    facet_wrap(~section, scales = "free", nrow = 1, ncol = 4) +
    theme_minimal() +
    
    labs(
      x="",
      y="",
      title=""
    ) +
    scale_fill_manual(values = c("#4287c7", "#f9b02d"), guide = FALSE) 
})
#train_conf_other_feedback
#train_conf_repeat
#train_conf_helpful
#train_conf_length
#train_conf_content
```

### Company data
```{r}
renderPlot({
  fields <- c("train_conf_comp_r_users", "train_conf_purchase", "train_conf_reason")
  facet_title <- c("How many people in your company use R?", "How likely are you to purchase RStudio products?", "Why did you attend the training?")
  content <- map2_df(fields, facet_title, ~getSummary(train_unique_selected(), .x, .y))
  ggplot(content, aes(x = reorder(response, as.numeric(response)), y = count)) +
    geom_bar(stat = "identity", aes(fill = section)) +
    facet_wrap(~section, scales = "free", nrow = 1, ncol = 3) +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 60, hjust = 1), 
      text = element_text( size = 14)
    ) +
    labs(
      x="",
      y="",
      title=""
    ) +
    scale_fill_manual(values = c("#4287c7", "#f9b02d", "#d54a30", "#c8c8c8"), guide = FALSE) 
})
#train_conf_comp_r_users
#train_conf_purchase
#train_conf_reason
```

### NPS 
```{r}
renderPlot({
  
  npsPlot(train_unique_selected()$train_conf_nps) +
    labs(
      x = paste0("How likely are you to recommend ", input$session, " to a friend?"),
      y = paste0(nrow(train_unique_selected()), "Survey Responses")
    )
  
  
  
})
```

### Overall Engagement
```{r}
renderPlot({
  n <- nrow(train_unique_selected())
  
  color  <- ifelse(train_unique_selected()$train_conf_overall < 7, "b", ifelse( train_unique_selected()$train_conf_overall> 8, "c", "a"))
  
  ggplot(train_unique_selected(), aes(x=train_conf_overall)) +
    geom_bar(aes(fill = color)) +
    theme_minimal() + 
    theme(
      title = element_text(color = "#404040"),
      text = element_text( size = 14)
    ) + 
    labs(
      x = paste0(input$session, " Overall Rating"),
      y = paste0(n, " Survey Responses"),
      title = paste0("Average Rating ", round(mean(train_unique_selected()$train_conf_overall, na.rm = TRUE),1))
    ) + 
    scale_fill_manual(values = c("#4287c7", "#f9b02d", "#789d57"), guide = FALSE)
  
})
```


Row 
----------------------
  ### {.no-title}
  
  ```{r}
valueBox(3, "Tracks - Advanced R, Shiny, Tidyverse", color = "white", icon = "fa-pencil")
```


### {.no-title}

```{r}
valueBox(2, "Days of Training", color = "white", icon = "fa-calendar")
```


### {.no-title}


```{r}
valueBox(221, "Paying Students", color = "white", icon = "fa-graduation-cap")
```

Other Comments
========================
  
  ### Other things we should know.
  
  ```{r}
# combine "train_conf_other_feedback", "conf_other_feedback" this is from the main survey into a table so they can scroll
feedback %>% 
  filter(source %in% c("train_conf_other_feedback", "conf_other_feedback")) %>% 
  select(Text, Sentiment = sentiment) %>% 
  datatable(extensions = 'Scroller', options = list(pageLength = 300, deferRender = TRUE,  scrollY = 200, lengthChange = FALSE, order = list(list(2,'desc')))) %>% 
  formatStyle(
    'Sentiment',
    color = styleInterval(c(0), c('#f9b02d', '#789d57'))
  ) 

```


Locations
========================
  
  ### Where did they all come from?
  
  ```{r}
leaflet() %>% addTiles()  %>% 
  addMarkers(data = attendees1, lat = ~ Latitude, lng = ~ Longitude, popup = attendees1$BillingCity)
```



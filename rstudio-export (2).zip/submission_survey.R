# Applicant Survey
library(shiny)
library(RMySQL)

## Database Information
host <- ""
dbname <- "unicorn"
user <- "bcarney"
password <- "uniconl0g1n"

## Table Information
table_name <- "submission_survey"

# con <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)

fieldsMandatory <- c("email", "position")

labelMandatory <- function(label) {
  tagList(
    label,
    span("*", class = "mandatory_star")
  )
}

appCSS <-
  ".mandatory_star { color: red; }"

shinyApp(
  ui = fixedPage(
    shinyjs::useShinyjs(),
    shinyjs::inlineCSS(appCSS),
    
    fluidRow(
      column(2),
      column(8,
             h2("Employment Survey"),
             
             id = "form",
             
             wellPanel(
               tagList(
                 tags$i("In an effort to make sure you fit the job and it you we've developed several questions to give us a better idea."), br(), br(),
                 
                 
                 tags$b("What job are you applying for?"),
                 span("*", class = "mandatory_star")
               ),
               selectInput("position", "", c("1", "2", "3"), width = NULL),
             
               hr(), 
               
               tags$b("What is your email?"), br(), br(),
               tags$textarea(id = "applicant_email", rows = 1, cols = 50), br(), br(),
                 
               hr(),
               
               radioButtons("experience_length", "How many years of experience do you have?", c("None", "1 to 2 years",  "3 to 4 years", "5 to 10 years"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(),
               
               tags$b("How long have you been using R?"),
               selectInput("eval_used_r", "", c("0 to 2 Years", "3 to 5 Years", "6 to 10 Years", "11 to 15 Years", "Over 16 Years"), width = NULL),
               
               hr(),
               
               tags$b("How many people in your company do you believe use R?"),
               selectInput("eval_r_users", "", c("<5",	">5<25", ">25<100", ">100", "I have no idea"), width = NULL),
               
               hr(),
               
               radioButtons("eval_install", "How was the installation of your evaluation?", c("Easy","Normal", "Complicated"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(),
               
               radioButtons("eval_docs", "Did the RStudio admin documentation provide everything you'd needed?", c("Yes", "No", "Not sure", "Didn't need it"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(),
               
               radioButtons("eval_complete", "Did you complete the installation and evaluation?", c("Yes","No", "Partially"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(), 
               
               tags$b("Please add information here if your eval was partially or not completed?"), br(), br(),
               tags$textarea(id = "eval_no_joy", rows = 4, cols = 50), br(), br(),
               
               
               hr(),
               
               tags$b("How would you rate your overall evaluation experience?"),
               sliderInput("eval_experience", "", 0, 10, 7, ticks = TRUE, width = NULL), 
               hr(),
               
               tags$b("How would you rate your overall product experience?"),
               sliderInput("eval_prod_experience", "", 0, 10, 7, ticks = TRUE, width = NULL), 
               
               hr(), 
               
               tags$b("Would you like to make a comment on your overall product or eval experience?"), br(), br(),
               tags$textarea(id = "eval_exp_prod_comment", rows = 4, cols = 50), br(), br(),
               
               hr(),
               
               tags$b("How likely are you to ever purchase RStudio commercial products?"),
               sliderInput("eval_purchase", "", 0, 10, 7, ticks = TRUE, width = NULL),
               
               hr(),
               
               tags$b("Please check which RStudio products are you still/currently using?"),
               checkboxInput("eval_rstudio_connect", "RStudio Connect", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_isp", "RStudio Server Pro", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_ssp", "Shiny Server Pro", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_os_desk", "Open Source RStudio Desktop", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_os_server", "Open Source RStudio Server", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_os_shiny", "Open Source Shiny Server", value = FALSE, width = NULL),
               checkboxInput("eval_rstudio_shinyapp", "shinyapps.io", value = FALSE, width = NULL),
               
               "If none what are you using instead?", br(), br(),
               tags$textarea(id = "eval_products_alt_used", rows = 1, cols = 50),
               
               hr(),
               
               tags$b("How likely is it that you would recommend RStudio Connect to a friend or colleague?"),
               sliderInput("eval_nps", "", 0, 10, 7, ticks = TRUE, width = NULL),
               
               hr(),
               
               radioButtons("eval_sales_talk", "Have you connected with RStudio sales?", c("called","emailed", "no contact"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(),
               
               radioButtons("eval_support_talk", "Have connected with RStudio support?", c("called","emailed", "no contact"), selected = NULL, inline = FALSE, width = NULL),
               
               hr(), 
               
               tags$b("What could we do better?"), br(), br(),
               tags$textarea(id = "eval_other_feedback", rows = 4, cols = 50), br(), br(),
               
               
               
               actionButton("submit", "Submit", class = "btn-primary"),
               
               hr(),
               
               textOutput("result")
             )
      ),
      column(2)
    )
  ),
  server = function(input, output, session) {
    
    values <- reactiveValues(dbdata = NULL, submitted = FALSE)
    
    observeEvent(input$reload_db, {
      con <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)
      values$dbdata <- dbReadTable(con, table_name)
      dbDisconnect(con)
    })
    
    mydata <- reactive({
      result <- as.data.frame(do.call(cbind, reactiveValuesToList(input)))
      
      return(result)
    })
    
    observeEvent(input$submit, {
      con <- dbConnect(MySQL(), host = host, dbname = dbname, user = user, password = password)
      
      dbWriteTable(con, table_name, mydata(), append = TRUE)
      
      values$submitted <- TRUE
      
      dbDisconnect(con)
    })
    
    output$mydat <- renderDataTable({
      return(values$dbdata[,-1])
    })
    
    output$result <- renderText({
      if (values$submitted) return("Successfully submitted!")
      else return("")
    })
    
    observe({
      mandatoryFilled <-
        vapply(fieldsMandatory,
               function(x) {
                 !is.null(input[[x]]) && input[[x]] != ""
               },
               logical(1))
      mandatoryFilled <- all(mandatoryFilled)
      
      shinyjs::toggleState(id = "submit", condition = mandatoryFilled)
    })    
  }
)
